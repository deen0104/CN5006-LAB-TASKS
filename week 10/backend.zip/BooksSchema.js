const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema({
    booktitle: { type: String, required: true },
    PubYear: { type: String },
    author: { type: String, required: true },
    Topic: { type: String },
    formate: { type: String, enum: ["Electronic", "Hard Copy"], default: "Electronic" },
});

const Book = mongoose.model("Book", bookSchema);

module.exports = Book;
