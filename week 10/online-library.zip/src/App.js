import React from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import AddBook from "./components/AddBook";
import ViewSingleBook from "./components/ViewSingleBook";
import ViewBooks from "./components/ViewBooks";
import UpdateBook from "./components/UpdateBook";
import DeleteBook from "./components/DeleteBook";

const App = () => {
  return (
    <Router>
      <nav>
        <Link to="/">View Books</Link>
        <Link to="/add">Add Book</Link>
        <Link to="/delete">Delete Book</Link>
      </nav>
      <Routes>
        <Route path="/" element={<ViewBooks />} />
        <Route path="/add" element={<AddBook />} />
        <Route path="/delete" element={<DeleteBook />} />
        <Route path="/update/:id" element={<UpdateBook />} />
        <Route path="/single/:id" element={<ViewSingleBook />} />
      </Routes>
    </Router>
  );
};

export default App;
