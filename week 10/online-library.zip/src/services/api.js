import axios from "axios";

const API_URL = "http://localhost:5000/api/books"; // Backend server URL

// Get all books
export const getAllBooks = async () => {
    return axios.get(`${API_URL}/allbooks`);
};

// Get a single book by ID
export const getBookById = async (id) => {
    return axios.get(`${API_URL}/getbook/${id}`);
};

// Add a new book
export const addBook = async (book) => {
    return axios.post(`${API_URL}/addbooks`, book);
};

// Update a book by ID
export const updateBook = async (id, updatedBook) => {
    return axios.post(`${API_URL}/updatebook/${id}`, updatedBook);
};

// Delete a book by ID
export const deleteBook = async (id) => {
    return axios.post(`${API_URL}/deleteBook/${id}`);
};
