import React, { useEffect, useState } from "react";
import { getAllBooks } from "../services/api";
import { Link } from "react-router-dom"; // Import Link for navigation

const ViewBooks = () => {
    const [books, setBooks] = useState([]);

    useEffect(() => {
        const fetchBooks = async () => {
            try {
                const response = await getAllBooks();
                setBooks(response.data);
            } catch (error) {
                console.error("Error fetching books", error);
            }
        };
        fetchBooks();
    }, []);

    return (
        <div>
            <h2>Book List</h2>
            {books.length ? (
                <ul>
                    {books.map((book) => (
                        <li key={book._id}>
                            {book.booktitle} by {book.author} ({book.PubYear})
                            {/* Add a link to the Update page */}
                            <Link to={`/update/${book._id}`}>Update</Link>

                            <Link to={`/single/${book._id}`}>View Book</Link>
                        </li>
                    ))}
                </ul>
            ) : (
                <p>No books available.</p>
            )}
        </div>
    );
};

export default ViewBooks;
