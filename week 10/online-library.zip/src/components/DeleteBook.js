import React, { useState, useEffect } from "react";
import { getAllBooks, deleteBook } from "../services/api";

const DeleteBook = () => {
    const [books, setBooks] = useState([]);

    useEffect(() => {
        const fetchBooks = async () => {
            try {
                const response = await getAllBooks();
                setBooks(response.data);
            } catch (error) {
                console.error("Error fetching books", error);
            }
        };
        fetchBooks();
    }, []);

    const handleDelete = async (id) => {
        if (window.confirm("Are you sure you want to delete this book?")) {
            try {
                await deleteBook(id);
                alert("Book deleted successfully!");
                setBooks(books.filter((book) => book._id !== id)); // Update the list after deletion
            } catch (error) {
                alert("Error deleting book");
            }
        }
    };

    return (
        <div>
            <h2>Delete Books</h2>
            {books.length ? (
                <ul>
                    {books.map((book) => (
                        <li key={book._id}>
                            {book.booktitle} by {book.author} ({book.PubYear})
                            <button onClick={() => handleDelete(book._id)}>Delete</button>
                        </li>
                    ))}
                </ul>
            ) : (
                <p>No books available to delete.</p>
            )}
        </div>
    );
};

export default DeleteBook;
