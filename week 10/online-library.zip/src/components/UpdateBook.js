import React, { useState, useEffect } from "react";
import { getBookById, updateBook } from "../services/api";
import { useParams, useNavigate } from "react-router-dom";

const UpdateBook = () => {
    const { id } = useParams(); // Get the book ID from the URL
    const navigate = useNavigate();

    const [book, setBook] = useState({
        booktitle: "",
        PubYear: "",
        author: "",
        Topic: "",
        formate: "",
    });

    useEffect(() => {
        const fetchBookDetails = async () => {
            try {
                const response = await getBookById(id);
                setBook(response.data);
            } catch (error) {
                console.error("Error fetching book details", error);
            }
        };
        fetchBookDetails();
    }, [id]);

    const handleChange = (e) => {
        setBook({ ...book, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await updateBook(id, book);
            alert("Book updated successfully!");
            navigate("/"); // Redirect to the book list after update
        } catch (error) {
            alert("Error updating book");
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input name="booktitle" value={book.booktitle} onChange={handleChange} placeholder="Title" required />
            <input name="PubYear" value={book.PubYear} onChange={handleChange} placeholder="Publication Year" />
            <input name="author" value={book.author} onChange={handleChange} placeholder="Author" />
            <input name="Topic" value={book.Topic} onChange={handleChange} placeholder="Topic" />
            <select name="formate" value={book.formate} onChange={handleChange}>
                <option value="Electronic">Electronic</option>
                <option value="Hard Copy">Hard Copy</option>
            </select>
            <button type="submit">Update Book</button>
        </form>
    );
};

export default UpdateBook;
