import React, { useEffect, useState } from "react";
import { getBookById } from "../services/api";
import { Link } from "react-router-dom"; // Import Link for navigation
import { useParams, useNavigate } from "react-router-dom";
const ViewBooks = () => {
    const { id } = useParams(); // Get the book ID from the URL
    const navigate = useNavigate();
    const [book, setBook] = useState([]);

    useEffect(() => {
        const fetchBook = async () => {
            try {
                const response = await getBookById(id);
                setBook(response.data);
            } catch (error) {
                console.error("Error fetching books", error);
            }
        };
        fetchBook();
    }, []);

    return (
        <div>
            <h2>Book Details</h2>
            <ul>
                {<li key={book._id}>
                    {book.booktitle} by {book.author} ({book.PubYear})

                </li>}
            </ul>

        </div>
    );
};

export default ViewBooks;
