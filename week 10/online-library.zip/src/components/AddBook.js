import React, { useState } from "react";
import { addBook } from "../services/api";

const AddBook = () => {
    const [book, setBook] = useState({
        booktitle: "",
        PubYear: "",
        author: "",
        Topic: "",
        formate: "",
    });

    const handleChange = (e) => {
        setBook({ ...book, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await addBook(book);
            alert("Book added successfully!");
            setBook({ booktitle: "", PubYear: "", author: "", Topic: "", formate: "" });
        } catch (error) {
            alert("Error adding book");
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input name="booktitle" value={book.booktitle} onChange={handleChange} placeholder="Title" required />
            <input name="PubYear" value={book.PubYear} onChange={handleChange} placeholder="Publication Year" />
            <input name="author" value={book.author} onChange={handleChange} placeholder="Author" />
            <input name="Topic" value={book.Topic} onChange={handleChange} placeholder="Topic" />
            <select name="formate" value={book.formate} onChange={handleChange}>
                <option value="">Select Format</option>
                <option value="Electronic">Electronic</option>
                <option value="Hard Copy">Hard Copy</option>
            </select>
            <button type="submit">Add Book</button>
        </form>
    );
};

export default AddBook;
